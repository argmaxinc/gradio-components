export default {
  plugins: [],
  svelte: {
    preprocess: [],
  },
};